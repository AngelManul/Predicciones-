// scripts.js

$(document).ready(function() {
    fetchAllStudents();
});

function showAddStudentForm() {
    $('#form-container').html(`
        <h2>Agregar Alumno</h2>
        <form id="add-student-form">
            <div class="form-group">
                <label>Nombre</label>
                <input type="text" class="form-control" name="Nombre" required>
            </div>
            <div class="form-group">
                <label>Matricula</label>
                <input type="text" class="form-control" name="Matricula" required>
            </div>
            <div class="form-group">
                <label>Turno</label>
                <input type="text" class="form-control" name="Turno" required>
            </div>
            <div class="form-group">
                <label>Plantel</label>
                <input type="text" class="form-control" name="Plantel" required>
            </div>
            <div class="form-group">
                <label>Edad</label>
                <input type="number" class="form-control" name="Edad" required>
            </div>
            <div class="form-group">
                <label>Genero</label>
                <input type="text" class="form-control" name="Genero" required>
            </div>
            <div class="form-group">
                <label>Promedio General</label>
                <input type="number" step="0.01" class="form-control" name="Promedio_General" required>
            </div>
            <div class="form-group">
                <label>Porcentaje de Asistencia</label>
                <input type="number" step="0.01" class="form-control" name="Porcentaje_de_asistencia" required>
            </div>
            <div class="form-group">
                <label>Numero de Materias Reprobadas</label>
                <input type="number" class="form-control" name="Numero_de_materias_reprobadas" required>
            </div>
            <div class="form-group">
                <label>Horas de Estudio Semanal</label>
                <input type="number" class="form-control" name="Horas_de_estudio_semanal" required>
            </div>
            <div class="form-group">
                <label>Cuatrimestres Cursados</label>
                <input type="number" class="form-control" name="Cuatrimestres_cursados" required>
            </div>
            <div class="form-group">
                <label>Tiene Beca</label>
                <input type="text" class="form-control" name="Tiene_beca" required>
            </div>
            <div class="form-group">
                <label>Participa en Actividades Extra</label>
                <input type="text" class="form-control" name="Participa_en_actividades_extra" required>
            </div>
            <div class="form-group">
                <label>Nivel de Estrés</label>
                <input type="number" class="form-control" name="Nivel_de_estres" required>
            </div>
            <div class="form-group">
                <label>Satisfacción con la Carrera</label>
                <input type="number" class="form-control" name="Satisfaccion_con_la_carrera" required>
            </div>
            <div class="form-group">
                <label>Tiempo para Llegar</label>
                <input type="number" class="form-control" name="Tiempo_para_llegar" required>
            </div>
            <div class="form-group">
                <label>Es Puntual</label>
                <input type="text" class="form-control" name="Es_puntual" required>
            </div>
            <div class="form-group">
                <label>Área de Mejora</label>
                <input type="text" class="form-control" name="Area_de_mejora" required>
            </div>
            <button type="submit" class="btn btn-primary">Agregar</button>
        </form>
    `);
    $('#add-student-form').on('submit', function(e) {
        e.preventDefault();
        addStudent();
    });
}

function addStudent() {
    const data = $('#add-student-form').serializeArray().reduce((obj, item) => {
        obj[item.name] = item.value;
        return obj;
    }, {});
    $.ajax({
        url: '/add_student',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: function(response) {
            alert('Alumno agregado exitosamente');
            fetchAllStudents();
        }
    });
}

function fetchAllStudents() {
    $.ajax({
        url: '/students',
        method: 'GET',
        success: function(response) {
            const tableBody = $('#students-table tbody');
            tableBody.empty();
            response.forEach(student => {
                tableBody.append(`
                    <tr>
                        <td>${student[0]}</td>
                        <td>${student[1]}</td>
                        <td>${student[2]}</td>
                        <td>${student[3]}</td>
                        <td>${student[4]}</td>
                        <td>${student[5]}</td>
                        <td>${student[6]}</td>
                        <td>${student[7]}</td>
                        <td>${student[8]}</td>
                        <td>${student[9]}</td>
                        <td>${student[10]}</td>
                        <td>${student[11]}</td>
                        <td>${student[12]}</td>
                        <td>${student[13]}</td>
                        <td>${student[14]}</td>
                        <td>${student[15]}</td>
                        <td>${student[16]}</td>
                        <td>${student[17]}</td>
                    </tr>
                `);
            });
        }
    });
}

function showUpdateStudentForm() {
    // Function to show update student form and handle update logic
}

function showSearchStudentForm() {
    $('#form-container').html(`
        <h2>Buscar Alumno</h2>
        <form id="search-student-form">
            <div class="form-group">
                <label>Matricula</label>
                <input type="text" class="form-control" name="matricula" required>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>
    `);
    $('#search-student-form').on('submit', function(e) {
        e.preventDefault();
        searchStudent();
    });
}

function searchStudent() {
    const matricula = $('#search-student-form input[name="matricula"]').val();
    $.ajax({
        url: `/student?matricula=${matricula}`,
        method: 'GET',
        success: function(response) {
            if (response.length === 0) {
                alert('Alumno no encontrado');
            } else {
                displayStudentData(response[0]);
            }
        }
    });
}

function displayStudentData(student) {
    $('#form-container').html(`
        <h2>Datos del Alumno</h2>
        <table class="table table-striped">
            <tr><td>Nombre</td><td>${student[0]}</td></tr>
            <tr><td>Matricula</td><td>${student[1]}</td></tr>
            <tr><td>Turno</td><td>${student[2]}</td></tr>
            <tr><td>Plantel</td><td>${student[3]}</td></tr>
            <tr><td>Edad</td><td>${student[4]}</td></tr>
            <tr><td>Genero</td><td>${student[5]}</td></tr>
            <tr><td>Promedio General</td><td>${student[6]}</td></tr>
            <tr><td>Porcentaje de Asistencia</td><td>${student[7]}</td></tr>
            <tr><td>Numero de Materias Reprobadas</td><td>${student[8]}</td></tr>
            <tr><td>Horas de Estudio Semanal</td><td>${student[9]}</td></tr>
            <tr><td>Cuatrimestres Cursados</td><td>${student[10]}</td></tr>
            <tr><td>Tiene Beca</td><td>${student[11]}</td></tr>
            <tr><td>Participa en Actividades Extra</td><td>${student[12]}</td></tr>
            <tr><td>Nivel de Estrés</td><td>${student[13]}</td></tr>
            <tr><td>Satisfacción con la Carrera</td><td>${student[14]}</td></tr>
            <tr><td>Tiempo para Llegar</td><td>${student[15]}</td></tr>
            <tr><td>Es Puntual</td><td>${student[16]}</td></tr>
            <tr><td>Área de Mejora</td><td>${student[17]}</td></tr>
        </table>
    `);
}
